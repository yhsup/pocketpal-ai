import {FIREBASE_FUNCTIONS_URL, HF_MIRROR_URL} from '@env';

// HF base domain. Override at build time via HF_MIRROR_URL (e.g. set to
// https://hf-mirror.com for a domestic mirror). Falls back to the official
// host when the variable is unset.
export const HF_DOMAIN = (HF_MIRROR_URL || 'https://huggingface.co').replace(
  /\/+$/,
  '',
);
export const HF_API_BASE = `${HF_DOMAIN}/api/models`;

// Fallback for Firebase Functions URL if not configured
const FIREBASE_BASE =
  FIREBASE_FUNCTIONS_URL || 'https://placeholder-firebase-functions.com';

export const urls = {
  // API URLs
  modelsList: () => `${HF_API_BASE}`,
  modelTree: (modelId: string) => `${HF_API_BASE}/${modelId}/tree/main`,
  modelSpecs: (modelId: string) => `${HF_API_BASE}/${modelId}`,

  // Web URLs
  modelDownloadFile: (modelId: string, filename: string) =>
    `${HF_DOMAIN}/${modelId}/resolve/main/${filename}`,
  modelWebPage: (modelId: string) => `${HF_DOMAIN}/${modelId}`,

  // Benchmark Endpoint
  benchmarkSubmit: () => `${FIREBASE_BASE}/api/v1/submit`,

  // Feedback Endpoint
  feedbackSubmit: () => `${FIREBASE_BASE}/feedback`,
};
